package utils;

public interface ISerializer {
    static void save() throws Exception {

    }

    static void load() throws Exception {

    }

    static String fileName() {
        return null;
    }
}
